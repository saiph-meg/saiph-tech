import { ReactNode } from "react";

export interface ColProps {
  children: ReactNode;
}
