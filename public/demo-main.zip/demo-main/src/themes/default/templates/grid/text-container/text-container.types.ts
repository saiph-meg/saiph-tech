import { ReactNode } from "react";

export interface TextContainerProps {
  children: ReactNode;
  className?: string;
}
